#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>

Adafruit_MPU6050 mpu;
bool mpuAktif = false;

// --- PIN SENSOR ---
const int trigPin = 5;
const int echoPin = 18;

// --- PIN OUTPUT ---
const int buzzerPin    = 19;
const int ledGempaPin  = 23; // LED Merah
const int ledBanjirPin = 4;  // LED Biru

// --- AMBANG BATAS BENCANA ---
const float batasGempa = 2.5; // Selisih getaran/kemiringan (m/s^2)
const int batasBanjir  = 50;  // Jarak air ke sensor (cm)

float lastX = 0, lastY = 0, lastZ = 0;
bool pembacaanPertama = true;

// Timer agar kedua alarm bisa menyala bersamaan tanpa saling menunggu
unsigned long waktuGempaTerakhir = 0;
const unsigned long durasiAlarmGempa = 3000; // Alarm gempa tahan 3 detik agar sempat digabung uji banjir

void setup() {
  Serial.begin(115200);

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(buzzerPin, OUTPUT);
  pinMode(ledGempaPin, OUTPUT);
  pinMode(ledBanjirPin, OUTPUT);

  // Cek MPU6050 tanpa menghentikan program jika belum terbaca
  if (mpu.begin()) {
    mpuAktif = true;
    Serial.println("✅ Sensor Gempa (MPU6050) Siap!");
  } else {
    Serial.println("⚠️ MPU6050 tidak terdeteksi, hanya sensor banjir yang aktif.");
  }
  Serial.println("=== SISTEM GABUNGAN GEMPA & BANJIR BERJALAN ===");
}

void loop() {
  unsigned long sekarang = millis();

  // 1. CEK KONDISI GEMPA (MPU6050)
  if (mpuAktif) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    if (pembacaanPertama) {
      lastX = a.acceleration.x;
      lastY = a.acceleration.y;
      lastZ = a.acceleration.z;
      pembacaanPertama = false;
    } else {
      float deltaX = abs(a.acceleration.x - lastX);
      float deltaY = abs(a.acceleration.y - lastY);
      float deltaZ = abs(a.acceleration.z - lastZ);

      lastX = a.acceleration.x;
      lastY = a.acceleration.y;
      lastZ = a.acceleration.z;

      // Jika terjadi guncangan, catat waktunya agar alarm bertahan selama 3 detik
      if (deltaX > batasGempa || deltaY > batasGempa || deltaZ > batasGempa) {
        waktuGempaTerakhir = sekarang;
      }
    }
  }
  bool statusGempa = (waktuGempaTerakhir > 0 && (sekarang - waktuGempaTerakhir < durasiAlarmGempa));

  // 2. CEK KONDISI BANJIR (HC-SR04)
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long durasi = pulseIn(echoPin, HIGH, 30000); // Timeout 30ms agar tidak macet
  int jarakAir = durasi * 0.034 / 2;
  bool statusBanjir = (jarakAir > 0 && jarakAir <= batasBanjir);

  // 3. EKSEKUSI ALARM (BISA SEKALI DUA ATAU SALAH SATU)
  if (statusGempa && statusBanjir) {
    // --- SEKALI DUA: GEMPA & BANJIR BERSAMAAN ---
    Serial.println("🚨🚨 DARURAT GANDA! GEMPA & BANJIR TERJADI BERSAMAAN! 🚨🚨");
    digitalWrite(ledGempaPin, HIGH);
    digitalWrite(ledBanjirPin, HIGH);
    tone(buzzerPin, 1500);
    delay(120);
    digitalWrite(ledGempaPin, LOW);
    digitalWrite(ledBanjirPin, LOW);
    tone(buzzerPin, 800);
    delay(120);
  } 
  else if (statusGempa) {
    // --- HANYA GEMPA ---
    Serial.println("🚨 PERINGATAN: GEMPA BUMI!");
    digitalWrite(ledBanjirPin, LOW);
    digitalWrite(ledGempaPin, HIGH);
    tone(buzzerPin, 1200);
    delay(150);
    digitalWrite(ledGempaPin, LOW);
    tone(buzzerPin, 700);
    delay(150);
  } 
  else if (statusBanjir) {
    // --- HANYA BANJIR ---
    Serial.print("⚠️ PERINGATAN: BANJIR! Jarak air: ");
    Serial.print(jarakAir);
    Serial.println(" cm");
    digitalWrite(ledGempaPin, LOW);
    digitalWrite(ledBanjirPin, HIGH);
    tone(buzzerPin, 900);
    delay(200);
    digitalWrite(ledBanjirPin, LOW);
    noTone(buzzerPin);
    delay(200);
  } 
  else {
    // --- KONDISI AMAN ---
    digitalWrite(ledGempaPin, LOW);
    digitalWrite(ledBanjirPin, LOW);
    noTone(buzzerPin);
    delay(100);
  }
}

