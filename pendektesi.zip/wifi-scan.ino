#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Definisi Pin & Tipe Sensor
#define DHTPIN 15
#define DHTTYPE DHT22

// Inisialisasi Sensor DHT & LCD (Alamat I2C: 0x27, 16 Kolom, 2 Baris)
DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  // Inisialisasi Serial Monitor
  Serial.begin(115200);
  Serial.println(F("--- Stasiun Cuaca Mini ESP32 ---"));

  // Inisialisasi Sensor DHT22
  dht.begin();

  // Inisialisasi LCD Display
  lcd.init();
  lcd.backlight(); // Menyala Layar Belakang LCD

  // Tampilan Awal (Splash Screen)
  lcd.setCursor(0, 0); // Kolom 0, Baris 0
  lcd.print("IoT Weather Stn");
  lcd.setCursor(0, 1); // Kolom 0, Baris 1
  lcd.print("Initializing...");
  delay(2000);
  lcd.clear();
}

void loop() {
  // Sensor DHT22 membutuhkan jeda minimal 2 detik antar pembacaan
  delay(2000);

  // Membaca Kelembapan & Suhu
  float kelembapan = dht.readHumidity();
  float suhu = dht.readTemperature();

  // Validasi Hasil Pembacaan Sensor
  if (isnan(kelembapan) || isnan(suhu)) {
    Serial.println(F("Gagal membaca data dari sensor DHT!"));
    lcd.setCursor(0, 0);
    lcd.print("Error Sensor!   ");
    return;
  }

  // Cetak ke Serial Monitor (Untuk Debugging)
  Serial.print(F("Suhu: "));
  Serial.print(suhu);
  Serial.print(F(" °C | Kelembapan: "));
  Serial.print(kelembapan);
  Serial.println(F(" %"));

  // Tampilkan Informasi ke Layar LCD 16x2
  // Baris 1: Informasi Suhu
  lcd.setCursor(0, 0);
  lcd.print("Suhu : ");
  lcd.print(suhu, 1); // Membatasi 1 desimal
  lcd.print((char)223); // Simbol Derajat (°)
  lcd.print("C  ");

  // Baris 2: Informasi Kelembapan
  lcd.setCursor(0, 1);
  lcd.print("Lembap: ");
  lcd.print(kelembapan, 1);
  lcd.print("%   ");
}
