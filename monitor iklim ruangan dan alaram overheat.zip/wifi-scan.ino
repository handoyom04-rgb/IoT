#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT22
#define LED_PIN 2
#define BUZZER_PIN 15
DHT dht(DHTPIN, DHTTYPE);
void setup() {
Serial.begin(115200);
dht.begin();
pinMode(LED_PIN, OUTPUT);
pinMode(BUZZER_PIN, OUTPUT);
Serial.println("System Monitoring Suhu Server Started...");
}
void loop() {
delay(2000);
float temp = dht.readTemperature();
float hum = dht.readHumidity();
if (isnan(temp) || isnan(hum)) {
Serial.println("Gagal membaca dari sensor DHT!");
return;
}
Serial.print("Suhu: "); Serial.print(temp); Serial.print(" °C | ");
Serial.print("Kelembapan: "); Serial.print(hum); Serial.println(" %");
if (temp > 30.0 || hum > 70.0) {
digitalWrite(LED_PIN, HIGH);
tone(BUZZER_PIN, 1000); // Bunyi Buzzer 1kHz
Serial.println(">>> WARNING: Kondisi Ruangan Abnormal! <<<");
} else {
digitalWrite(LED_PIN, LOW);
noTone(BUZZER_PIN);
}
}